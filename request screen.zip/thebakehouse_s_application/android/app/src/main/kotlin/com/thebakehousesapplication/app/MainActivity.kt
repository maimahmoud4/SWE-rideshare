package com.thebakehousesapplication.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
