// lib/core/utils/image_constant.dart
class ImageConstant {
  // Base path for all assets
  static String _basePath = 'assets/images/';

  // Placeholder image for fallback
  static String imgPlaceholder = '${_basePath}placeholder.png';

  // Model Ride Profile Menu Model Screen
  static String imgEllipse43 = '${_basePath}img_ellipse_43.png';

  // Ride Profile Menu Screen
  static String img941 = '${_basePath}img_941.svg';
  static String imgBars = '${_basePath}img_bars.svg';
  static String imgBattery = '${_basePath}img_battery.svg';
  static String imgDiscount = '${_basePath}img_discount.svg';
  static String imgGroup = '${_basePath}img_group.png';
  static String imgHeart = '${_basePath}img_heart.svg';
  static String imgHouse = '${_basePath}img_house.svg';
  static String imgLocationTarhget = '${_basePath}img_location_tarhget.svg';
  static String imgMap = '${_basePath}img_map.svg';
  static String imgMobileSignal = '${_basePath}img_mobile_signal.svg';
  static String imgNotification = '${_basePath}img_notification.svg';
  static String imgSearch = '${_basePath}img_search.svg';
  static String imgTriangle = '${_basePath}img_triangle.svg';
  static String imgUser = '${_basePath}img_user.svg';
  static String imgWallet = '${_basePath}img_wallet.svg';
  static String imgWifi = '${_basePath}img_wifi.svg';

  // Ride Profile Menu Screen Screen
  static String imgAboutUs = '${_basePath}img_about_us.svg';
  static String imgComplain = '${_basePath}img_complain.svg';
  static String imgHelpAndSupport = '${_basePath}img_help_and_support.svg';
  static String imgHistory = '${_basePath}img_history.svg';
  static String imgLogout = '${_basePath}img_logout.svg';
  static String imgSettings = '${_basePath}img_settings.svg';

  // Custom Image View Screen
  static String imgImageNotFound = '${_basePath}image_not_found.png';
}
