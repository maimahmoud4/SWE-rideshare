// lib/core/utils/image_constant.dart
class ImageConstant {
  // Base path for all assets
  static String _basePath = 'assets/images/';

  // Placeholder image for fallback
  static String imgPlaceholder = '${_basePath}placeholder.png';

  // Driver Authentication Screen
  static String imgScreenshot20250408at22536pmremovebgpreview1 =
      '${_basePath}img_screenshot20250408at22536pmremovebgpreview_1.png';
  static String imgScreenshot20250408at22908pmremovebgpreview1 =
      '${_basePath}img_screenshot20250408at22908pmremovebgpreview_1.png';

  // Custom Image View Screen
  static String imgImageNotFound = '${_basePath}image_not_found.png';
}
